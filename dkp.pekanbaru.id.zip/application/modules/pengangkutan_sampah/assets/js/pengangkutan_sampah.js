
                    $('#tanggal_angkut').datepicker({dateFormat: 'yy-mm-dd'});