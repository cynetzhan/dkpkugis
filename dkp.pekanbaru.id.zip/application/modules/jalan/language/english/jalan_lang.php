<?php defined('BASEPATH') || exit('No direct script access allowed');


$lang['jalan_manage']      = 'Manage jalan';
$lang['jalan_edit']        = 'Edit';
$lang['jalan_true']        = 'True';
$lang['jalan_false']       = 'False';
$lang['jalan_create']      = 'Create';
$lang['jalan_list']        = 'List';
$lang['jalan_new']       = 'New';
$lang['jalan_edit_text']     = 'Edit this to suit your needs';
$lang['jalan_no_records']    = 'There are no jalan in the system.';
$lang['jalan_create_new']    = 'Create a new jalan.';
$lang['jalan_create_success']  = 'jalan successfully created.';
$lang['jalan_create_failure']  = 'There was a problem creating the jalan: ';
$lang['jalan_create_new_button'] = 'Create New jalan';
$lang['jalan_invalid_id']    = 'Invalid jalan ID.';
$lang['jalan_edit_success']    = 'jalan successfully saved.';
$lang['jalan_edit_failure']    = 'There was a problem saving the jalan: ';
$lang['jalan_delete_success']  = 'record(s) successfully deleted.';
$lang['jalan_delete_failure']  = 'We could not delete the record: ';
$lang['jalan_delete_error']    = 'You have not selected any records to delete.';
$lang['jalan_actions']     = 'Actions';
$lang['jalan_cancel']      = 'Cancel';
$lang['jalan_delete_record']   = 'Delete this jalan';
$lang['jalan_delete_confirm']  = 'Are you sure you want to delete this jalan?';
$lang['jalan_edit_heading']    = 'Edit jalan';

// Create/Edit Buttons
$lang['jalan_action_edit']   = 'Save jalan';
$lang['jalan_action_create']   = 'Create jalan';

// Activities
$lang['jalan_act_create_record'] = 'Created record with ID';
$lang['jalan_act_edit_record'] = 'Updated record with ID';
$lang['jalan_act_delete_record'] = 'Deleted record with ID';

//Listing Specifics
$lang['jalan_records_empty']    = 'No records found that match your selection.';
$lang['jalan_errors_message']    = 'Please fix the following errors:';

// Column Headings
$lang['jalan_column_created']  = 'Created';
$lang['jalan_column_deleted']  = 'Deleted';
$lang['jalan_column_modified'] = 'Modified';
$lang['jalan_column_deleted_by'] = 'Deleted By';
$lang['jalan_column_created_by'] = 'Created By';
$lang['jalan_column_modified_by'] = 'Modified By';

// Module Details
$lang['jalan_module_name'] = 'jalan';
$lang['jalan_module_description'] = 'Your module description';
$lang['jalan_area_title'] = 'jalan';

// Fields
$lang['jalan_field_nama'] = 'Nama';
$lang['jalan_field_armada'] = 'Armada';
$lang['jalan_field_html'] = 'HTML';
$lang['jalan_field_geom'] = 'Geom';
