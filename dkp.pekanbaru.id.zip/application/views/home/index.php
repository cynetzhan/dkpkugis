<div class="container-fluid" style="padding-top: 40px;background-color:#222">
 <div class="row">
   <div id="banner" class="carousel slide" data-ride="carousel">
     <ol class="carousel-indicators">
       <li data-target="#banner" data-slide-to="1" class='active'></li>
     </ol>
     <div class="carousel-inner">
       <div class="item active" style="background-image:url('assets/images/dkp.jpg');background-size:cover"><img src="assets/images/trsp.png" style="height:90vh;max-width:100%;opacity:0;" class="img-responsive" /><a href="#" class="carousel-caption"><h3 style="background-color:rgba(0,0,0,.7);padding:5px 20px">Selamat Datang di SIG DKP Kota Pekanbaru</h3></a></div>
     </div>
     <a class="left carousel-control" href="#banner" data-slide="prev">
       <span class="glyphicon glyphicon-chevron-left"></span>
     </a>
     <a class="right carousel-control" href="#banner" data-slide="next">
       <span class="glyphicon glyphicon-chevron-right"></span>
     </a>
   </div>
  </div>
</div>
<div class="container" style="padding-top:40px">
  <h3>Layanan Kami</h3>
 <div class="row">
  <div class="col-sm-10 col-sm-offset-1">
   <div class="row">
    <div class="col-sm-4">
   <div class="thumbnail">
    <img class="img-rounded" src="images/kota-pekanbaru.jpg?width=200&height=120" />
    <p class="text-center"><strong>Lihat Informasi TPS</strong></p>
    <p>Anda dapat melihat lorem ipsum dolor sit amet pada tautan diatas</p>
   </div>
  </div>
  <div class="col-sm-4">
   <div class="thumbnail">
    <img class="img-rounded" src="images/kota-pekanbaru.jpg?width=200&height=120" />
    <p>Lihat Informasi TPS</p>
    <p>Anda dapat melihat lorem ipsum dolor sit amet pada tautan diatas</p>
   </div>
  </div>
  <div class="col-sm-4">
   <div class="thumbnail">
    <img class="img-rounded" src="images/kota-pekanbaru.jpg?width=200&height=120" />
    <p>Lihat Informasi TPS</p>
    <p>Anda dapat melihat lorem ipsum dolor sit amet pada tautan diatas</p>
   </div>
  </div>
   </div>
  </div>
 </div>
</div>