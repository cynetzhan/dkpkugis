<h2>Selamat Datang Di Dinas Kebersihan dan Pertamanan Kota Pekanbaru</h2/>
</head>
<body>
<img align="left" alt="dkp" src="dkp.jpg" />
</body>
</html>
<img src="application/views/images/dkp.jpg">
